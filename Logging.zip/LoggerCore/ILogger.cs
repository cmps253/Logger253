﻿namespace LoggerCore
{
    public interface ILogger
    {
        void Log(string msg);
    }
}